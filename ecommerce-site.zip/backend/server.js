const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const Product = require('./models/Product');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost/ecommerce', { useNewUrlParser: true, useUnifiedTopology: true });

app.get('/api/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

// Add demo products
app.get('/api/init', async (req, res) => {
  const count = await Product.countDocuments();
  if (count === 0) {
    await Product.insertMany([
      {
        name: 'Wireless Headphones',
        price: 59.99,
        description: 'High-quality wireless headphones with noise cancellation.',
        image: 'https://via.placeholder.com/300x200?text=Headphones',
        review: 4
      },
      {
        name: 'Smartwatch',
        price: 120.00,
        description: 'Stylish smartwatch with heart-rate monitor and GPS.',
        image: 'https://via.placeholder.com/300x200?text=Smartwatch',
        review: 5
      },
      {
        name: 'Running Shoes',
        price: 75.50,
        description: 'Comfortable and durable running shoes for all terrains.',
        image: 'https://via.placeholder.com/300x200?text=Shoes',
        review: 4
      }
    ]);
    res.send('Demo products added');
  } else {
    res.send('Products already exist');
  }
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
